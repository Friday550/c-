// Programmer:		Your Name
// Date:			Date
// Program Name:	The name of the program
// Chapter:			Chapter # - Chapter name
// Description:		2 complete English sentences describing what the program does,
//					algorithm used, etc.

#define _CRT_SECURE_NO_WARNINGS // Disable warnings (and errors) when using non-secure versions of printf, scanf, strcpy, etc.
#include <stdio.h> // Needed for working with printf and scanf

int main(void)
{
	// Constant and Variable Declarations
	double dropHeight = 0.0;
	const double COEFF_MIN = 0.0;
	const double COEFF_MAX = 1.0;
	double coeffOfRest = 0.0;
	const INCH = 1;

	// *** Your program goes here ***

	// *** INPUT & VALIDATION ***

	printf("Enter the initial height of the ball (in feet): ");
	scanf("%lf", &dropHeight);
	while (dropHeight <= 0) {
		printf("   The initial height of the ball must be a positive number.\n");
		printf("   Please re-enter the initial height of the ball (in feet):");
		scanf("%lf", &dropHeight);
	}
	printf("Enter the balls' coefficient of restitution (0.0 to 1.0): ");
	scanf("%lf", &coeffOfRest);
	//if (coeffOfRest == 1) {

		while (coeffOfRest < COEFF_MIN || coeffOfRest > COEFF_MAX) {
			printf("   The coefficient of restitution must be between 0.0 and 1.0\n");
			printf("inclusive.\n");
			printf("   Please re-enter the balls' coefficient of restitution (0.0 to 1.0):\n");
			scanf("%lf", &coeffOfRest);
		}
		//printf("With a coefficient of restitution equal to 1.0, the ball will bounce\n");
		//printf("forever!\n");
		//return 0;
	//}

	// *** PROCESSING ***
	int ft = INCH * 12;


	return 0;
} // end main()
